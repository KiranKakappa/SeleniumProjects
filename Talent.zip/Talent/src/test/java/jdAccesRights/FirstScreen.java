package jdAccesRights;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FirstScreen {

	public static void main(String[] args) 
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(20));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(4));
		driver.get("http://10.35.183.7:81/SPADev/LoginHome/Logout");
		driver.findElement(By.xpath("//input[@id='username']")).sendKeys("10476");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Pakiravva123@");
		driver.findElement(By.id("customCheck1")).click();
		driver.findElement(By.xpath("//button[@id='Login']")).click();
		System.out.println(driver.getTitle());
		System.out.println(driver.getCurrentUrl());
		driver.findElement(By.xpath("//img[@id='menuPopupIDImg']")).click();
		driver.findElement(By.xpath("(//p[contains(text(),'Manage current and prospective employees data and ')])[2]")).click();
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//a[@routerlink='/jdaccesslist']"))));
		driver.findElement(By.xpath("(//a[@href='#/jdaccesslist'])[1]")).click();
		driver.findElement(By.xpath("(//button[normalize-space()='ADD NEW'])[1]")).click();
		driver.findElement(By.xpath("(//div[@class='mat-select-arrow-wrapper ng-tns-c131-12'])[1]")).click();
		List<WebElement>list=driver.findElements(By.xpath("//span[@class='mat-option-text']"));
		//driver.findElement(By.xpath("")).click();
		System.out.println(driver.findElement(By.xpath("(//span[@class='mat-option-text'])[1]")));
		driver.quit();
	}
}