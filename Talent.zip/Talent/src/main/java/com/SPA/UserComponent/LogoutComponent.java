package com.SPA.UserComponent;

import org.openqa.selenium.WebDriver;

public class LogoutComponent {
	
	public boolean executeLogoutAction(WebDriver driver) {
		return true;
	}
	
	
}
