package com.SPA.UserComponent;

public class ChangePasswordComponent {

}
