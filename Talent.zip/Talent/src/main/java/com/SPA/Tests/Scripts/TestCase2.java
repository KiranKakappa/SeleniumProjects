package com.SPA.Tests.Scripts;

public class TestCase2 {

}
