package com.SPA.Tests;

public interface AbstractTest {
	
	public void execute();
	
	public void loadStepsData();
	
}
