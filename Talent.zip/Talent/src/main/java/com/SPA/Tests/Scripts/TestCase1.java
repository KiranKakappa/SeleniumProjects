package com.SPA.Tests.Scripts;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.SPA.Home.HomeComponents;
import com.SPA.Login.LoginComponent;
import com.SPA.Talent.JobDescription.JDAccessRightsHandler;
import com.SPA.Tests.AbstractTest;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestCase1 implements AbstractTest{
	
	private WebDriver driver;
	private List<String> stepsList;
	private Map<Integer, Boolean> stepsResult;
	private static int stepIndex = 0;
	
	public TestCase1(String url) {
		WebDriverManager.chromedriver().setup();
		this.driver = new ChromeDriver();
		driver.get(url);
	}
	
	@Override
	public void loadStepsData() {
		// TODO Auto-generated method stub
		
	}
	
	private void updateStepResult(boolean result) {
		
		stepsResult.put(stepIndex, result);
		stepIndex++;
	}
	
	@Override
	public void execute() {
		
		LoginComponent loginComponent = new LoginComponent();
		updateStepResult(loginComponent.enterEmployeeId("10234", driver));
		updateStepResult(loginComponent.enterPassword("password", driver));
		updateStepResult(loginComponent.agreeToTermsAndConditions(driver));
		updateStepResult(loginComponent.executeLoginAction(driver));
		
		HomeComponents homeComponent = new HomeComponents();
		updateStepResult(homeComponent.chooseRequiredOption(4));
		updateStepResult(homeComponent.chooseRequiredSection(1));
		updateStepResult(homeComponent.chooseRequiredSubSection(1));
		
		JDAccessRightsHandler jdAccessRightsHandler = new JDAccessRightsHandler();
		updateStepResult(jdAccessRightsHandler.executeAddNewRightsAction(driver));
		updateStepResult(jdAccessRightsHandler.selectDepartment(driver, 2));
		
		// continue rest of the steps
	}
}
