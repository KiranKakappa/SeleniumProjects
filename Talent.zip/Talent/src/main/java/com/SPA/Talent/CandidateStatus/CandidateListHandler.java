package com.SPA.Talent.CandidateStatus;

public class CandidateListHandler {

}
