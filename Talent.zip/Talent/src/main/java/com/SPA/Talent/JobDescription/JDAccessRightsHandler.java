package com.SPA.Talent.JobDescription;

import org.openqa.selenium.WebDriver;

public class JDAccessRightsHandler {
	
	public boolean executeAddNewRightsAction(WebDriver driver) {
		return true;
	}
	
	public boolean executeSelectAndEditAction(WebDriver driver) {
		return true;
	}
	
	public boolean executeSelectAndDeleteAction(WebDriver driver) {
		return true;
	}
	
	public boolean executeSubmitAction(WebDriver driver) {
		return true;
	}
	
	public boolean executeCancelAction(WebDriver driver) {
		return true;
	}
	
	public boolean selectCompany(WebDriver driver, int index) {
		return true;
	}
	
	public boolean verifyCostCenterAutoPopulation(String costCenter) {
		return true;
	}
	
	public boolean selectDepartment(WebDriver driver, int index) {
		return true;
	}
	
	public boolean selectCadre(WebDriver driver , int index) {
		return true;
	}
	
	public boolean setPosition(WebDriver driver , String position) {
		return true;
	}
	
	public boolean selectQuestionCreater(WebDriver driver, String value) {
		return true;
	}
	
	public boolean selectQuestionApprover1(WebDriver driver, String value) {
		return true;
	}
	
	public boolean selectQuestionApprover2(WebDriver driver, String value) {
		return true;
	}
	
	public boolean selectQuestionApprover3(WebDriver driver, String value) {
		return true;
	}
	
}
