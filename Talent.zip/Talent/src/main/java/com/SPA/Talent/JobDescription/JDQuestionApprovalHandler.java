package com.SPA.Talent.JobDescription;

public class JDQuestionApprovalHandler {

}
