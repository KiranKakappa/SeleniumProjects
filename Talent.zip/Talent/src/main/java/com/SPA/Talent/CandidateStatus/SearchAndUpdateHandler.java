package com.SPA.Talent.CandidateStatus;

public class SearchAndUpdateHandler {

}
