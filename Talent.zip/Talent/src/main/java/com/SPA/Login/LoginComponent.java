package com.SPA.Login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginComponent {
	
	public boolean enterEmployeeId(String Id, WebDriver driver) {
		
		return true;
	}
	
	public boolean enterPassword(String password, WebDriver driver) {
		return true;
	}
	
	public boolean agreeToTermsAndConditions(WebDriver driver) {
		return true;
	}
	
	public boolean executeLoginAction(WebDriver driver) {
		return true;
	}
}
