package com.SPA.Utilities;

public class ConfigHandler {

}
