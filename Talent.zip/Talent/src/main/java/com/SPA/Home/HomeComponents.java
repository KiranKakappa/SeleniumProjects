package com.SPA.Home;

public class HomeComponents {
	
	/*
	 * fuction to choose Talent
	 */
	public boolean chooseRequiredOption(int index) {
		return true;
	}
	
	/*
	 * function to choose required model
	 */
	
	public boolean chooseRequiredSection(int index) {
		return true;
	}
	
	/*
	 * function to choose JD Access rights
	 */
	public boolean chooseRequiredSubSection(int index) {
		return true;
	}
	
}
