package com.SPA;

import com.SPA.Tests.Scripts.TestCase1;

public class ExecuteScripts {
	
	private static final String URL = "";
	
	public static void main(String[] args) {
		
		TestCase1 testCase1 = new TestCase1(URL);
		testCase1.execute();

	}

}
