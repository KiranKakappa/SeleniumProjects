package auto;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Utilities {
	WebDriver driver;

	public Utilities(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}

	//Login Locators for SPA
	@FindBy(xpath="//input[@id='username']")
	WebElement EmployeeID;
	
	@FindBy(xpath="//input[@id='password']")
	WebElement Elepassword;

	@FindBy(id="customCheck1")
	WebElement checkbox;
	
	@FindBy(xpath="//button[@id='Login']")
	WebElement button;
	
	public void loginapplication(String EmployeeNumber ,String password)
	{
		EmployeeID.sendKeys(EmployeeNumber);
		Elepassword.sendKeys(password);
		checkbox.click();
		button.click();
	}
	//Path to Talent Module
		@FindBy(xpath="//img[@id='menuPopupIDImg']")
		WebElement Menu;
		
		@FindBy(xpath="//div[4]//div[2]//a[1]//p[1]")
		WebElement TalentModule;
		
		@FindBy(xpath="(//a[normalize-space()='JD Access Rights'])[1]")
		WebElement JDAccessRights;
		
	public void pathToTalentModule()
	{
		Menu.click();
		TalentModule.click();
		JDAccessRights.click();
	}
	public void goTo()
	{
		driver.get("http://10.35.183.7:81/SPADev/LoginHome/Logout");
	}
	
}