package auto;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FirstScreen {

	public static void main(String[] args) 
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(20));
		Utilities Login=new Utilities(driver);
		Login.goTo();
		Login.loginapplication("10476","Pakiravva123@");
		
		System.out.println(driver.getTitle());
		System.out.println(driver.getCurrentUrl());
		Login.pathToTalentModule();
		driver.findElement(By.xpath("(//button[normalize-space()='ADD NEW'])[1]")).click();
		driver.findElement(By.xpath("(//div[@class='mat-select-arrow-wrapper ng-tns-c131-12'])[1]")).click();
		List<WebElement>list=driver.findElements(By.xpath("//span[@class='mat-option-text']"));
		System.out.println(driver.findElement(By.xpath("(//span[@class='mat-option-text'])[1]")));
		driver.quit();
	}
}